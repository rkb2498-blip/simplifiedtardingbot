# Binance Futures Testnet Trading Bot

A simplified Python trading bot that places MARKET and LIMIT orders on Binance USDT-M Futures Testnet.

The app uses direct REST API calls with `requests`, includes CLI input validation, structured logging, and error handling.

## Features

- Places MARKET orders
- Places LIMIT orders
- Supports BUY and SELL
- Uses Binance Futures Testnet base URL
- Validates CLI input
- Logs API requests, responses, and errors
- Separates client/API logic from CLI logic

## Binance Testnet Setup

1. Register or log in to Binance Futures Testnet.
2. Generate API key and API secret.
3. Make sure you are using the USDT-M Futures Testnet environment.
4. This project uses the following base URL:

```text
[testnet.binancefuture.com](https://testnet.binancefuture.com)
