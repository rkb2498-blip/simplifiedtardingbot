import argparse
import sys
from typing import Optional

from src.binance_client import BinanceFuturesClient
from src.config import get_settings
from src.exceptions import BinanceAPIError, BinanceNetworkError, InputValidationError
from src.logger import setup_logger


VALID_SIDES = {"BUY", "SELL"}
VALID_ORDER_TYPES = {"MARKET", "LIMIT"}


def positive_float(value: str) -> float:
    try:
        parsed = float(value)
    except ValueError as exc:
        raise argparse.ArgumentTypeError("Value must be a valid number.") from exc

    if parsed <= 0:
        raise argparse.ArgumentTypeError("Value must be greater than zero.")

    return parsed


def validate_order_input(
    symbol: str,
    side: str,
    order_type: str,
    quantity: float,
    price: Optional[float],
) -> None:
    if not symbol or not symbol.strip():
        raise InputValidationError("Symbol is required.")

    if side.upper() not in VALID_SIDES:
        raise InputValidationError("Side must be BUY or SELL.")

    if order_type.upper() not in VALID_ORDER_TYPES:
        raise InputValidationError("Order type must be MARKET or LIMIT.")

    if quantity <= 0:
        raise InputValidationError("Quantity must be greater than zero.")

    if order_type.upper() == "LIMIT" and price is None:
        raise InputValidationError("Price is required for LIMIT orders.")

    if price is not None and price <= 0:
        raise InputValidationError("Price must be greater than zero.")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Place orders on Binance USDT-M Futures Testnet."
    )

    parser.add_argument(
        "--symbol",
        required=True,
        help="Trading symbol, for example BTCUSDT.",
    )

    parser.add_argument(
        "--side",
        required=True,
        choices=sorted(VALID_SIDES),
        help="Order side: BUY or SELL.",
    )

    parser.add_argument(
        "--type",
        required=True,
        choices=sorted(VALID_ORDER_TYPES),
        help="Order type: MARKET or LIMIT.",
    )

    parser.add_argument(
        "--quantity",
        required=True,
        type=positive_float,
        help="Order quantity.",
    )

    parser.add_argument(
        "--price",
        type=positive_float,
        default=None,
        help="Order price. Required for LIMIT orders.",
    )

    return parser


def print_order_summary(
    symbol: str,
    side: str,
    order_type: str,
    quantity: float,
    price: Optional[float],
) -> None:
    print("\nOrder Request Summary")
    print("---------------------")
    print(f"Symbol      : {symbol.upper()}")
    print(f"Side        : {side.upper()}")
    print(f"Order Type  : {order_type.upper()}")
    print(f"Quantity    : {quantity}")

    if order_type.upper() == "LIMIT":
        print(f"Price       : {price}")


def print_order_response(response: dict) -> None:
    print("\nOrder Response Details")
    print("----------------------")
    print(f"Order ID    : {response.get('orderId', 'N/A')}")
    print(f"Status      : {response.get('status', 'N/A')}")
    print(f"Executed Qty: {response.get('executedQty', 'N/A')}")
    print(f"Avg Price   : {response.get('avgPrice', 'N/A')}")

    print("\nFull Response")
    print("-------------")
    for key, value in response.items():
        print(f"{key}: {value}")


def main() -> int:
    logger = setup_logger()
    parser = build_parser()
    args = parser.parse_args()

    try:
        validate_order_input(
            symbol=args.symbol,
            side=args.side,
            order_type=args.type,
            quantity=args.quantity,
            price=args.price,
        )

        settings = get_settings()

        client = BinanceFuturesClient(
            api_key=settings.api_key,
            api_secret=settings.api_secret,
            base_url=settings.base_url,
            logger=logger,
        )

        print_order_summary(
            symbol=args.symbol,
            side=args.side,
            order_type=args.type,
            quantity=args.quantity,
            price=args.price,
        )

        response = client.place_order(
            symbol=args.symbol,
            side=args.side,
            order_type=args.type,
            quantity=args.quantity,
            price=args.price,
        )

        print_order_response(response)
        print("\nSuccess: order placed successfully.")
        return 0

    except InputValidationError as exc:
        logger.error("Input validation error: %s", exc)
        print(f"\nFailure: invalid input - {exc}", file=sys.stderr)
        return 1

    except BinanceAPIError as exc:
        logger.error("Binance API error: %s", exc)
        print(f"\nFailure: Binance API error - {exc}", file=sys.stderr)
        return 1

    except BinanceNetworkError as exc:
        logger.error("Network failure: %s", exc)
        print(f"\nFailure: network error - {exc}", file=sys.stderr)
        return 1

    except Exception as exc:
        logger.exception("Unexpected application error")
        print(f"\nFailure: unexpected error - {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
